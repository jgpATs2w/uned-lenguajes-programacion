int ejercicio1(bool debug);
