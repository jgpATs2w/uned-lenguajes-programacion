int ejercicio2(bool debug);
