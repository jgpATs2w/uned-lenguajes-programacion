int ejercicio4(bool debug);
