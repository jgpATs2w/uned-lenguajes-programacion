int ejercicio3(bool debug);
